from django.apps import AppConfig


class VenueEventConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Venue_Event'
